import React from 'react';
import LoginForm from '../components/Auth/LoginForm';

function Login() {
  return (
    <div>
      <h1>Bienvenido</h1>
      <LoginForm />
    </div>
  );
}

export default Login;
