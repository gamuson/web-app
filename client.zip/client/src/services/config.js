export const API_URL = '/api';
