import React from 'react';
import RegisterForm from '../components/Auth/RegisterForm';

function Register() {
  return (
    <div>
      <h1>Crear Cuenta</h1>
      <RegisterForm />
    </div>
  );
}

export default Register;
